/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.smartcity;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 *
 * @author GURJOT SINGH
 */
public class ConnectionClass {

    private static ConnectionClass single_instance = null;
    Connection connection;

    private ConnectionClass() {
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/smartcity", "root", "");
            if (connection != null) {
                System.out.println("connected");

                String statement = "CREATE TABLE IF NOT EXISTS birthcertificate(id INT NOT NULL AUTO_INCREMENT, "
                        + "name VARCHAR(255),"
                        + "father_name VARCHAR(255), "
                        + "mother_name VARCHAR(255), "
                        + "address VARCHAR(255), "
                        + "dob VARCHAR(255), "
                        + "tob VARCHAR(255), "
                        + "birth_place VARCHAR(255), isApproved Int, "
                        + " EmpId Int, "
                        + "CustId Int, "
                        + "PRIMARY KEY(id))";
                PreparedStatement preparedStatement = connection.prepareStatement(statement);
                preparedStatement.execute();
                String deathStatement = "CREATE TABLE IF NOT EXISTS deathcertificates"
                        + "(id INT NOT NULL AUTO_INCREMENT, "
                        + "name VARCHAR(255), "
                        + "gender VARCHAR(255), "
                        + "father_name VARCHAR(255), "
                        + "mother_name VARCHAR(255), "
                        + "deathplace VARCHAR(255), "
                        + "dateofDeath VARCHAR(255), "
                        + "reasonofdeath VARCHAR(255), "
                        + "isApproved Int, EmpId Int, CustId Int, "
                        + "PRIMARY KEY(id))";
                PreparedStatement preparedDStatement = connection.prepareStatement(deathStatement);
                preparedDStatement.execute();
                String empStatement = "CREATE TABLE IF NOT EXISTS employee"
                        + "(id INT NOT NULL AUTO_INCREMENT, "
                        + "name VARCHAR(255), "
                        + "qualification VARCHAR(255), "
                        + "joiningdate VARCHAR(255), "
                        + "email VARCHAR(255),"
                        + "password VARCHAR(255), "
                        + "role VARCHAR(255), "
                        + "isApproved Int, EmpId Int, CustId Int, "
                        + "PRIMARY KEY(id))";
                PreparedStatement preparedEStatement = connection.prepareStatement(empStatement);
                preparedEStatement.execute();

                String complaintStatement = "CREATE TABLE IF NOT EXISTS complaints"
                        + "(id INT NOT NULL AUTO_INCREMENT, "
                        + "title VARCHAR(255), "
                        + "description VARCHAR(255), "
                        + "reply VARCHAR(255), "
                        + "EmpId Int, CustId Int, "
                        + "PRIMARY KEY(id))";
                PreparedStatement preparedCStatement = connection.prepareStatement(complaintStatement);
                preparedCStatement.execute();
            }

        } catch (SQLException ex) {
            Logger.getLogger(ConnectionClass.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public static ConnectionClass getInstance() {
        if (single_instance == null) {
            single_instance = new ConnectionClass();
        }
        return single_instance;
    }
}
